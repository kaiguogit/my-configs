
                                <ul id="subnav">

								<div id="logindiv" style="text-align: right;">
                                                <li>Welcome, <?php echo $login; ?></li>
                                                <li><a href="logout.php">[logout]</a></li>

                                </ul>
								
                </div>

